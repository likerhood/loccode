# Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 53.33 | 65.00 | 73.33 | 75.00 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 78.33 | 63.03 | 47.04 | 0.00 |
| Module | 25.00 | 33.33 | 36.67 | 38.33 | 40.00 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 43.33 | 31.58 | 25.97 | 3.33 |
| Function | 5.00 | 8.33 | 10.00 | 11.67 | 13.33 | 13.33 | 13.33 | 16.67 | 16.67 | 16.67 | 16.67 | 16.67 | 16.67 | 18.33 | 18.33 | 8.51 | 4.48 | 3.33 |

## Metric Notes

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 48.33 | 59.51 | 18.86 | 26.00 | 30.00 | 35.93 | 12.34 | 16.29 | 6.67 | 9.75 | 2.74 | 3.76 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 48.33 | 59.51 | 18.86 | 26.00 | 30.00 | 35.93 | 12.27 | 16.19 | 6.67 | 9.75 | 2.36 | 3.37 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 48.33 | 59.51 | 18.86 | 26.00 | 30.00 | 35.93 | 12.26 | 16.16 | 6.67 | 10.58 | 2.20 | 3.20 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 48.33 | 59.51 | 18.86 | 26.00 | 30.00 | 35.93 | 12.26 | 16.16 | 6.67 | 10.58 | 2.20 | 3.20 |

