# Strict Three-Level Localization Metrics

- Evaluated: 60
- Note: Module/Function are derived from GALA staged file candidates and repo_structures.

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 16.67 | 23.33 | 28.33 | 30.00 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 31.67 | 35.00 | 27.06 | 46.67 |
| Module | 3.33 | 11.67 | 11.67 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 14.86 | 11.01 | 53.33 |
| Function | 0.00 | 0.00 | 0.00 | 1.67 | 1.67 | 3.33 | 3.33 | 5.00 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 10.90 | 4.86 | 53.33 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.


## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 31.67 | 36.69 | 14.28 | 17.70 | 13.33 | 17.92 | 6.11 | 8.51 | 5.00 | 9.20 | 3.75 | 3.91 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 31.67 | 36.69 | 14.28 | 17.70 | 13.33 | 17.92 | 6.11 | 8.51 | 6.67 | 10.05 | 3.42 | 3.71 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 31.67 | 36.69 | 14.28 | 17.70 | 13.33 | 17.92 | 6.11 | 8.51 | 6.67 | 10.05 | 2.85 | 3.18 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 31.67 | 36.69 | 14.28 | 17.70 | 13.33 | 17.92 | 6.11 | 8.51 | 6.67 | 10.05 | 2.85 | 3.18 |

## Stage Breakdown

| Stage | Total | Acc@1 | Acc@5 | Acc@10 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| snapshot_seed | 60 | 18.33 | 31.67 | 31.67 | 31.67 | 36.94 | 28.38 | 46.67 |
| code_seed | 60 | 18.33 | 31.67 | 31.67 | 31.67 | 36.94 | 28.38 | 46.67 |
| matched | 60 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 100.00 |
| edit_target | 60 | 3.33 | 3.33 | 3.33 | 3.33 | 5.83 | 4.29 | 81.67 |
| final | 60 | 16.67 | 31.67 | 31.67 | 31.67 | 35.00 | 27.06 | 46.67 |
