# Strict Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 13.33 | 16.67 | 18.33 | 20.00 | 21.67 | 21.67 | 21.67 | 21.67 | 21.67 | 23.33 | 23.33 | 25.00 | 25.00 | 26.67 | 28.33 | 24.31 | 19.49 | 0.00 |
| Module | 1.67 | 1.67 | 1.67 | 3.33 | 5.00 | 5.00 | 5.00 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 5.96 | 3.88 | 10.00 |
| Function | 0.00 | 1.67 | 1.67 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 5.00 | 5.00 | 5.00 | 5.00 | 5.00 | 5.00 | 5.00 | 3.32 | 2.06 | 13.33 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 21.67 | 27.18 | 10.62 | 12.42 | 6.67 | 7.92 | 1.68 | 2.53 | 3.33 | 4.44 | 0.83 | 1.31 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 23.33 | 28.02 | 10.00 | 11.64 | 6.67 | 7.92 | 1.62 | 2.42 | 5.00 | 5.69 | 1.02 | 1.64 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 28.33 | 33.25 | 9.44 | 10.97 | 6.67 | 7.92 | 1.62 | 2.42 | 5.00 | 6.67 | 1.24 | 2.00 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 28.33 | 33.25 | 9.44 | 10.97 | 6.67 | 7.92 | 1.62 | 2.42 | 5.00 | 6.67 | 1.24 | 2.00 |

