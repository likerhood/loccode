# Strict Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 43.33 | 55.00 | 55.00 | 55.00 | 55.00 | 55.00 | 55.00 | 55.00 | 55.00 | 56.67 | 56.67 | 56.67 | 56.67 | 56.67 | 56.67 | 70.44 | 58.82 | 6.67 |
| Module | 5.00 | 10.00 | 18.33 | 20.00 | 21.67 | 21.67 | 21.67 | 21.67 | 25.00 | 25.00 | 26.67 | 28.33 | 28.33 | 28.33 | 28.33 | 26.10 | 20.22 | 8.33 |
| Function | 0.00 | 3.33 | 5.00 | 6.67 | 11.67 | 11.67 | 11.67 | 13.33 | 15.00 | 15.00 | 15.00 | 16.67 | 16.67 | 18.33 | 18.33 | 11.24 | 7.66 | 8.33 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 55.00 | 63.43 | 42.43 | 45.78 | 21.67 | 29.17 | 11.67 | 15.39 | 13.33 | 17.74 | 6.27 | 8.35 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 56.67 | 65.10 | 42.56 | 46.03 | 25.00 | 31.67 | 11.67 | 15.51 | 15.00 | 18.28 | 6.18 | 8.39 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 56.67 | 65.10 | 42.44 | 45.85 | 28.33 | 35.56 | 11.87 | 15.92 | 18.33 | 23.06 | 6.55 | 9.10 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 56.67 | 65.10 | 42.44 | 45.85 | 38.33 | 46.81 | 12.38 | 16.88 | 26.67 | 32.61 | 6.84 | 9.61 |

