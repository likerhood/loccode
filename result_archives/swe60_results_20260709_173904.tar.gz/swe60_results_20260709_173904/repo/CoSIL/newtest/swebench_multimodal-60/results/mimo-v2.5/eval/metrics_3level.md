# Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 43.33 | 56.67 | 60.00 | 63.33 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 65.00 | 52.28 | 34.04 | 0.00 |
| Module | 23.33 | 30.00 | 36.67 | 40.00 | 43.33 | 46.67 | 48.33 | 48.33 | 48.33 | 48.33 | 48.33 | 48.33 | 48.33 | 48.33 | 48.33 | 31.18 | 21.76 | 0.00 |
| Function | 5.00 | 10.00 | 11.67 | 13.33 | 13.33 | 15.00 | 15.00 | 15.00 | 16.67 | 18.33 | 21.67 | 21.67 | 25.00 | 25.00 | 25.00 | 9.66 | 6.13 | 0.00 |

## Metric Notes

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 8.85 | 3.75 | 4.04 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 10.37 | 3.64 | 4.29 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 11.66 | 3.98 | 4.60 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 11.66 | 3.98 | 4.60 |

