# Strict Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 16.67 | 23.33 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 25.00 | 52.28 | 34.04 | 0.00 |
| Module | 13.33 | 16.67 | 18.33 | 18.33 | 20.00 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 31.18 | 21.76 | 0.00 |
| Function | 3.33 | 5.00 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 6.67 | 9.66 | 6.13 | 0.00 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 8.85 | 3.75 | 4.04 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 10.37 | 3.64 | 4.29 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 11.66 | 3.98 | 4.60 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 25.00 | 40.91 | 24.06 | 25.95 | 23.33 | 32.34 | 16.95 | 18.23 | 6.67 | 11.66 | 3.98 | 4.60 |

