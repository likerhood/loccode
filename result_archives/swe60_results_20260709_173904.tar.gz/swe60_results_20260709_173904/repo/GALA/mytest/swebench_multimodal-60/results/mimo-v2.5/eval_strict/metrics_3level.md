# Strict Three-Level Localization Metrics

- Evaluated: 60
- Note: Module/Function are derived from GALA staged file candidates and repo_structures.

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 13.33 | 25.00 | 30.00 | 33.33 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 58.44 | 39.59 | 0.00 |
| Module | 5.00 | 11.67 | 11.67 | 15.00 | 20.00 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 23.33 | 18.22 | 14.89 | 1.67 |
| Function | 3.33 | 3.33 | 3.33 | 5.00 | 6.67 | 8.33 | 8.33 | 8.33 | 8.33 | 10.00 | 10.00 | 10.00 | 11.67 | 11.67 | 11.67 | 10.40 | 7.30 | 1.67 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.


## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 35.00 | 54.02 | 30.22 | 33.65 | 23.33 | 28.04 | 9.66 | 13.40 | 8.33 | 12.23 | 4.54 | 5.68 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 35.00 | 54.02 | 30.22 | 33.65 | 23.33 | 28.04 | 9.66 | 13.40 | 10.00 | 13.73 | 4.75 | 6.14 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 35.00 | 54.02 | 30.22 | 33.65 | 23.33 | 28.04 | 9.66 | 13.40 | 11.67 | 16.90 | 4.80 | 6.55 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 35.00 | 54.02 | 30.22 | 33.65 | 23.33 | 28.04 | 9.66 | 13.40 | 11.67 | 16.90 | 4.80 | 6.55 |

## Stage Breakdown

| Stage | Total | Acc@1 | Acc@5 | Acc@10 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| snapshot_seed | 60 | 16.67 | 35.00 | 35.00 | 35.00 | 64.83 | 42.26 | 0.00 |
| code_seed | 60 | 16.67 | 35.00 | 35.00 | 35.00 | 64.83 | 42.26 | 0.00 |
| matched | 60 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 100.00 |
| edit_target | 60 | 6.67 | 11.67 | 11.67 | 11.67 | 27.22 | 15.77 | 36.67 |
| final | 60 | 13.33 | 35.00 | 35.00 | 35.00 | 58.44 | 39.59 | 0.00 |
