# Strict Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 5.00 | 6.67 | 10.00 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 11.67 | 13.33 | 19.75 | 11.87 | 0.00 |
| Module | 6.67 | 10.00 | 11.67 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 13.33 | 12.64 | 10.22 | 10.00 |
| Function | 1.67 | 1.67 | 1.67 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 3.33 | 4.29 | 2.80 | 10.00 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 11.67 | 19.27 | 7.08 | 8.22 | 13.33 | 15.94 | 8.93 | 10.35 | 3.33 | 4.89 | 2.78 | 3.00 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 11.67 | 19.31 | 6.17 | 7.14 | 13.33 | 15.94 | 8.81 | 10.26 | 3.33 | 4.89 | 2.63 | 2.84 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 13.33 | 20.98 | 4.78 | 5.58 | 13.33 | 15.94 | 8.70 | 10.15 | 3.33 | 6.25 | 2.95 | 3.27 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 13.33 | 20.98 | 4.78 | 5.58 | 13.33 | 15.94 | 8.70 | 10.15 | 3.33 | 6.25 | 2.95 | 3.27 |

