# Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 61.67 | 76.67 | 83.33 | 83.33 | 85.00 | 85.00 | 86.67 | 86.67 | 86.67 | 86.67 | 86.67 | 86.67 | 86.67 | 86.67 | 86.67 | 71.96 | 45.95 | 6.67 |
| Module | 10.00 | 23.33 | 30.00 | 31.67 | 45.00 | 51.67 | 51.67 | 51.67 | 51.67 | 51.67 | 53.33 | 60.00 | 60.00 | 60.00 | 60.00 | 23.79 | 20.35 | 6.67 |
| Function | 8.33 | 18.33 | 23.33 | 25.00 | 30.00 | 31.67 | 33.33 | 33.33 | 33.33 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 35.00 | 17.10 | 11.12 | 6.67 |

## Metric Notes

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 36.67 | 53.18 | 40.81 | 38.81 | 33.33 | 40.42 | 9.77 | 14.72 | 13.33 | 20.90 | 7.04 | 9.39 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 36.67 | 53.18 | 40.52 | 38.52 | 33.33 | 40.97 | 8.74 | 13.47 | 13.33 | 21.69 | 6.33 | 8.79 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 36.67 | 53.46 | 40.24 | 38.22 | 40.00 | 48.22 | 8.59 | 13.45 | 13.33 | 22.53 | 5.26 | 7.72 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 36.67 | 53.46 | 40.24 | 38.22 | 51.67 | 63.66 | 8.86 | 14.08 | 26.67 | 41.56 | 5.61 | 8.72 |

