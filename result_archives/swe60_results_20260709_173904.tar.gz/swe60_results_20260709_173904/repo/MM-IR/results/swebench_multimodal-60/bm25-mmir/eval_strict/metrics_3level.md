# Strict Three-Level Localization Metrics

- Evaluated: 60

## Ranking Metrics

| Level | Acc@1 | Acc@2 | Acc@3 | Acc@4 | Acc@5 | Acc@6 | Acc@7 | Acc@8 | Acc@9 | Acc@10 | Acc@11 | Acc@12 | Acc@13 | Acc@14 | Acc@15 | MRR@15 | MAP@15 | Empty |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| File | 3.33 | 10.00 | 11.67 | 15.00 | 16.67 | 18.33 | 21.67 | 21.67 | 21.67 | 21.67 | 21.67 | 21.67 | 28.33 | 30.00 | 33.33 | 31.60 | 19.74 | 0.00 |
| Module | 5.00 | 13.33 | 16.67 | 21.67 | 23.33 | 26.67 | 26.67 | 26.67 | 30.00 | 30.00 | 33.33 | 33.33 | 35.00 | 36.67 | 36.67 | 24.53 | 18.39 | 0.00 |
| Function | 1.67 | 6.67 | 6.67 | 10.00 | 11.67 | 16.67 | 16.67 | 18.33 | 20.00 | 20.00 | 20.00 | 20.00 | 20.00 | 20.00 | 20.00 | 18.85 | 10.86 | 0.00 |

## Metric Notes

`Acc@K` uses the strict LocAgent-style full-coverage standard: it is 1 only when top-k predictions cover all gold locations for that level.

`Set Metrics @8/@10/@15` evaluate only the top-k predictions. `Set Metrics @All` evaluates the full prediction set without truncation.

`SL` is strict full-coverage success: it is 1 only when all gold locations for that level are included in the evaluated prediction set.

## Set Metrics @8

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 21.67 | 33.86 | 11.04 | 14.34 | 26.67 | 34.96 | 7.78 | 11.59 | 18.33 | 23.12 | 6.46 | 7.99 |

## Set Metrics @10

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 21.67 | 34.02 | 9.33 | 12.44 | 30.00 | 38.67 | 7.53 | 11.45 | 20.00 | 24.17 | 5.67 | 7.30 |

## Set Metrics @15

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 33.33 | 48.33 | 8.44 | 12.60 | 36.67 | 47.37 | 6.81 | 10.61 | 20.00 | 25.37 | 4.42 | 5.94 |

## Set Metrics @All

| File SL | File REC | File PRE | File F1 | Module SL | Module REC | Module PRE | Module F1 | Function SL | Function REC | Function PRE | Function F1 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 33.33 | 48.33 | 8.44 | 12.60 | 36.67 | 47.37 | 6.81 | 10.61 | 20.00 | 25.37 | 4.42 | 5.94 |
